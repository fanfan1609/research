<?php
require 'src/GifFrameExtractor/GifFrameExtractor.php';

$gifFilePath = 'test.gif';

if (GifFrameExtractor::isAnimatedGif($gifFilePath)) { // check this is an animated GIF

    $gfe = new GifFrameExtractor();
    $gfe->extract($gifFilePath);

    foreach ($gfe->getFrames() as $i => $frame) {
    	imagejpeg($frame['image'],"image".$i.".jpeg");
    	echo "<img src='image".$i.".jpeg'> <br>";    	
    }
}
?>

